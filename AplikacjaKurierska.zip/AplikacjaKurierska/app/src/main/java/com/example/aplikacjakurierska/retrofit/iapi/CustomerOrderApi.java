package com.example.aplikacjakurierska.retrofit.iapi;

public interface CustomerOrderApi {
}
