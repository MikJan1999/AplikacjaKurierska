package com.example.aplikacjakurierska.retrofit.model;

import java.util.Date;
import java.util.List;

public class Product {

    private Long id;
    private String productName;
    private Double productPrice;
    private String productPictureUrl;
    private String productDescription;
    //Czy produkt jest na sprzedaż czy został wycofany
   private String status;
    private Float amountInStock;
    private Date CreateAt;
    private List<PositionCustomerOrder> positionCustomerOrders;

    public Product() {

    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", productName='" + productName + '\'' +
                ", productPrice=" + productPrice +
                ", productPictureUrl='" + productPictureUrl + '\'' +
                ", productDescription='" + productDescription + '\'' +
                ", status='" + status + '\'' +
                ", amountInStock=" + amountInStock +
                ", CreateAt=" + CreateAt +
                '}';
    }

    public Date getCreateAt() {
        return CreateAt;
    }

    public void setCreateAt(Date createAt) {
        CreateAt = createAt;
    }

    public Product(Long id, String productName, Double productPrice,
                   String productPictureUrl, String productDescription
                 , String status
//                   List<PositionCustomerOrder> positionCustomerOrders
            , Float amountInStock, Date CreateAt) {
        this.id = id;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productPictureUrl = productPictureUrl;
        this.productDescription = productDescription;
        this.status = status;
        this.amountInStock = amountInStock;
        this.CreateAt = CreateAt;
//        this.positionCustomerOrders = positionCustomerOrders;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductPictureUrl() {
        return productPictureUrl;
    }

    public void setProductPictureUrl(String productPictureUrl) {
        this.productPictureUrl = productPictureUrl;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Float getAmountInStock() {
        return amountInStock;
    }

    public void setAmountInStock(Float amountInStock) {
        this.amountInStock = amountInStock;
    }

//    public List<PositionCustomerOrder> getPositionCustomerOrders() {
//        return positionCustomerOrders;
//    }
//
//    public void setPositionCustomerOrders(List<PositionCustomerOrder> positionCustomerOrders) {
//        this.positionCustomerOrders = positionCustomerOrders;
//    }


}


