package com.example.aplikacjakurierska.ActivityCustomer;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.aplikacjakurierska.R;
import com.example.aplikacjakurierska.retrofit.model.Product;
import com.example.aplikacjakurierska.retrofit.model.Test;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    private List<Product> testList;
    TextView productName;
    TextView productPrice;
    TextView productPictureURL;
    TextView productDescription;
    TextView idForSale;
    TextView amountInStock;
    TextView date;

public ProductAdapter(List<Product> testList){
    this.testList = testList;
}
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_list,parent,false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull ProductAdapter.ViewHolder holder, int position) {
    Product product = testList.get(position);
    holder.productName.setText(product.getProductName());
    holder.productPrice.setText(String.valueOf(product.getProductPrice()));
    holder.productPictureURL.setText(String.valueOf(product.getProductPictureUrl()));
    holder.productDescription.setText(product.getProductDescription());
    holder.amountInStock.setText(String.valueOf(product.getAmountInStock()) );
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
//        String formattedDate = dateFormat.format(product.getCreateAt());
//        holder.date.setText(formattedDate);

    //    holder.itemText.setText(test.getText());
//    holder.BoolItemText.setText(String.valueOf(test.getWarunek()));
    }

    @Override
    public int getItemCount() {
        System.out.println(testList.size()+ "ROZMAIR LISTY");
        System.out.println(testList.size()+"  "+ "getitemCount kurwa");
        return testList.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView productName;
        TextView productPrice;
        TextView productPictureURL;
        TextView productDescription;
        TextView date;
        TextView amountInStock;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productName = itemView.findViewById(R.id.productName);
            productPrice = itemView.findViewById(R.id.productPrice);
            productPictureURL = itemView.findViewById(R.id.productPictureURL);
            productDescription = itemView.findViewById(R.id.productDescription);
            amountInStock = itemView.findViewById(R.id.amountInStock);
//            date = itemView.findViewById(R.id.date);
//            idForSale = itemView.findViewById(R.id.idForSale);
        }


    }






}
