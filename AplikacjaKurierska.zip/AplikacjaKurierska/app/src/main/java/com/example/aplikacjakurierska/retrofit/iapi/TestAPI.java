package com.example.aplikacjakurierska.retrofit.iapi;

import com.example.aplikacjakurierska.retrofit.model.Product;
import com.example.aplikacjakurierska.retrofit.model.Test;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface TestAPI {


    @GET("/get")
    Call<List<Test>> getAll();
}
