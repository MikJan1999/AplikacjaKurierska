package com.example.aplikacjakurierska.retrofit.model;

import androidx.annotation.NonNull;

public class Test {
 private Long id;
 private String text;
private Boolean warunek;

    @Override
    public String toString() {
        return "Test{" +
                "id=" + id +
                ", text='" + text + '\'' +
                ", warunek=" + warunek +
                '}';
    }

    public Boolean getWarunek() {
        return warunek;
    }

    public void setWarunek(Boolean warunek) {
        this.warunek = warunek;
    }

    public Test(Long id, String text, Boolean warunek) {
        this.id = id;
        this.text = text;
        this.warunek = warunek;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


}
