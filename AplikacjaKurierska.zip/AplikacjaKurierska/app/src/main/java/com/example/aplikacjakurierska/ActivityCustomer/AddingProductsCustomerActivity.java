package com.example.aplikacjakurierska.ActivityCustomer;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.aplikacjakurierska.ActivityClient.MainNewActivity;
import com.example.aplikacjakurierska.R;
import com.example.aplikacjakurierska.retrofit.RetrofitServ;
import com.example.aplikacjakurierska.retrofit.iapi.ProductApi;
import com.example.aplikacjakurierska.retrofit.model.Product;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class AddingProductsCustomerActivity extends AppCompatActivity {

ProductApi productApi;

    private List<Product> productList;

    Retrofit retrofit;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adding_products_customer);
        viewListProduct();
        addProductCustomers();
    }

    private void addProductCustomers() {
        TextInputEditText nameProductAdd = findViewById(R.id.nameProductAdd);
        TextInputEditText priceProductAdd  = findViewById(R.id.priceProductAdd);
        TextInputEditText descriptionProductAdd  = findViewById(R.id.descriptionProductAdd);
        TextInputEditText amountProductAdd  = findViewById(R.id.amountProductAdd);
        Switch switchselect = findViewById(R.id.switchselect);
        AppCompatButton buttonAddProductForSale = findViewById(R.id.buttonAddProductForSale);



RetrofitServ retrofitServ = new RetrofitServ();
        ProductApi productApi = retrofitServ.getRetrofit().create(ProductApi.class);
        buttonAddProductForSale.setOnClickListener(view -> {
            String nameproduct = String.valueOf(nameProductAdd.getText());
            String priceproduct = String.valueOf(priceProductAdd.getText());
            String descriptionproduct = String.valueOf(descriptionProductAdd.getText());
            String amountproduct = String.valueOf(amountProductAdd.getText());

            Product productadd = new Product();
            productadd.setProductName(nameproduct);
            productadd.setProductPrice(Double.valueOf(priceproduct));
            productadd.setProductDescription(descriptionproduct);
            productadd.setAmountInStock(Float.valueOf(amountproduct));

//            switchselect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                    if (isChecked) {
//                        productadd.setStatus("WITHDRAWN");
//                    } else {
//                        productadd.setStatus("AVAILABLE");
//                    }
//                }
//            });
            if (switchselect.isChecked()) {
                productadd.setStatus("WITHDRAWN");
            } else {
                productadd.setStatus("AVAILABLE");
            }
productApi.add(productadd).enqueue(new Callback<Product>() {
    @Override
    public void onResponse(Call<Product> call, Response<Product> response) {
        Toast.makeText(AddingProductsCustomerActivity.this, "Pomyślnie zapisano produkt", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onFailure(Call<Product> call, Throwable t) {
        Toast.makeText(AddingProductsCustomerActivity.this, "Nie zapisano produktu", Toast.LENGTH_SHORT).show();
    Logger.getLogger(AddingProductsCustomerActivity.class.getName() ).log(Level.SEVERE,"Error ");
    }
});

        });


    }

    private void viewListProduct() {
            RecyclerView recyclertest = findViewById(R.id.recycleproduct);


            RetrofitServ retrofitServ = new RetrofitServ();
            ProductApi productApi = retrofitServ.getRetrofit().create(ProductApi.class);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
            recyclertest.setLayoutManager(linearLayoutManager);
//        recyclertest.setLayoutManager(new LinearLayoutManager(this));


            productApi.getAll().enqueue(new Callback<List<Product>>() {
                @Override
                public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                    if(response.isSuccessful()){
                        List<Product> productResponse = response.body();
                        if(productResponse !=null){
                            productList = productResponse;
                            if(!productList.isEmpty()){
                                ProductAdapter productAdapter = new ProductAdapter(productList);
                                recyclertest.setAdapter(productAdapter);
                            }else {
                                System.out.println("Pusta lista");
                            }
                        }else {
                            System.out.println("odpowiddz Api jest pusta");
                        }
                    }else {
                        System.out.println("błąd odpowiedzi");
                    }
                    Toast.makeText(AddingProductsCustomerActivity.this, "pomylsnie zapisano", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailure(Call<List<Product>> call, Throwable t) {
                    Toast.makeText(AddingProductsCustomerActivity.this, "Nie zapisano jest bład", Toast.LENGTH_SHORT).show();
                    Logger.getLogger(AddingProductsCustomerActivity.class.getName()).log(Level.SEVERE,"Dupa");
                }
            }) ;
        }
        }




